# encoding: utf-8
from TemplateMiddleware.AddresMiddlewares import Address_Middleware
from SpiderTools.Tool import get_jp_value
from SpiderTools.Tool import re_text
from SpiderTools.JsFunc import JsFunc
from scrapy.selector import Selector
from OperateDB.OpMongodb import Op_MongoDB
from Env.ParseYaml import DBConfigParser
import requests
import execjs
import json
import ssl
import time
import jsonpath

ssl._create_default_https_context = ssl._create_unverified_context

class LianJia:
    requests.packages.urllib3.disable_warnings()
    def __init__(self,code,entity_code,entity_name,key=None):
        self.midd = Address_Middleware(code).Invoking_Diff()
        self.code = code
        self.entity_code = entity_code
        self.entity_name = entity_name

        config = DBConfigParser()
        fixed_db = config.get_fixed_db()
        temp_db = config.get_temp_db()

        self.mongodb = Op_MongoDB(db=fixed_db, coll=entity_code, key=key)
        self.tempmongodb = Op_MongoDB(db=temp_db, coll=entity_code, key=key)
        self.address_mongodb = Op_MongoDB(db='spider_address', coll=entity_code, key='null')

    def strat_request(self):

        url_list = self.midd['url']
        pform = self.midd['parm']
        pmethod = self.midd['method']
        purl = self.midd['url']
        if not purl:
            #self.log.error('没有请求的url')
            raise Exception('没有请求的url')
        final_out = self.midd['final_out']
        con_out = self.midd['content_out']
        domain = self.midd['domain']
        content_url = self.midd['content_url']
        text_type = self.midd['textType']
        node = self.midd['node']

        addres_url = self.address_mongodb.S_Mongodb()
        if addres_url:
            addres_url = self.address_mongodb.S_Mongodb(output='URL_')
        else:
            self.address_mongodb.I_Mongodb([{'URL_': m_} for m_ in self.midd['url']])

        u = content_url
        if '{' not in u and '}' not in u:
            import pymongo
            try:
                self.mongodb = Op_MongoDB(db='spider_url_fixed', coll=self.entity_code, key='null')
                self.tempmongodb = Op_MongoDB(db='spider_url_temp', coll=self.entity_code, key='null')
            except pymongo.errors.OperationFailure as e:
                pass

        meta = {"v_parm": '', "final_out": final_out, "con_out": con_out,
                'db': '', 'textType': text_type, 'node': node,
                "entity_name": self.entity_name,
                "entity_code": self.entity_code,
                'domain': domain,
                'content_url': content_url,
                }

        for url in self.midd['url']:

            if url not in addres_url:
                continue

            index = url_list.index(url)

            if pmethod == 'GET':
                parm = pform[index]
                formdata = None
                meta['parm'] = parm
            if pmethod == 'POST':
                formdata = pform[index]
                parm = None
                meta['parm'] = formdata

            data = requests.request(url=url,method=pmethod, headers=self.midd['header'],data=formdata,params=parm,
                                    verify=False)
            meta['p_url'] = url
            #self.grad_adress_parse(data,meta)

    def grad_adress_parse(self, response, meta):
        '''地址抓包模式解析并入库
        :param response:
        :return:
        '''
        v_parm = meta['v_parm']
        finalout = meta['final_out']
        conout = meta['con_out']
        entity_name = meta['entity_name']
        entity_code = meta['entity_code']
        text_type = meta['textType']
        node = meta['node']
        content_url = meta['content_url']
        parm = meta['parm']
        p_url = meta['p_url']

        final = []

        encode = response.encoding
        if not encode:
            encode = 'utf-8'
        content_data = str(response.content, encoding=encode)

        if not content_data:
            #self.log.error('去请求网站返回数据为空')
            print(1)
            raise Exception('去请求网站返回数据为空')

        if text_type != 'html':

            try:
                content_data = execjs.eval(content_data)
            except:
                content_data = content_data

        if node:
            if text_type == 'json':
                content = jsonpath.jsonpath(content_data, node)
                if not content:
                    content = jsonpath.jsonpath(content_data, node.replace('[*]', ''))[0]
                    if not content:
                        print(1)
                        raise Exception('地址抓包没有匹配到数据')
                    content = eval(content)
                content_data = content
            elif text_type == 'html':
                response_data = Selector(text=content_data)
                content_data = response_data.xpath(node[:-1])
        else:
            if isinstance(content_data, str):
                if content_data[0] == '[':
                    if content_data[-1] != ']':
                        content_data = content_data + ']'
                    content_data = eval(content_data)
                else:
                    response_data = Selector(text=content_data)
                    content_data = [response_data]

        if not content_data:
            # if v_parm:
            #    db.U_Mongodb({"companyname": v_parm,"status":"1"}, {"companyname": v_parm, "status": "0"})
            #self.log.error('地址抓包内容经过处理后值为空，请检查问题')
            return False

        # 挂包内容解析
        for sel in content_data:
            url = content_url
            unit = []
            grad = {}
            param = []
            data = jsonpath.jsonpath(conout, '$.data[?(@)]')
            data = data if data else [conout]
            for item in data:
                code = item['code']
                par = item['expr']

                if 'algo' in item:
                    algo = item['algo']
                else:
                    algo = ''

                if text_type == 'json':

                    if '$.' in par:
                        values = get_jp_value(sel, par)
                        if isinstance(values, list):
                            values = values[0] if len(values) > 0 else ''
                        elif isinstance(values, str):
                            values = values
                        else:
                            values = ''
                    else:
                        try:
                            values = sel[par]
                        except:
                            values = ''

                elif text_type == 'html':
                    # if len(content_data) == 1:
                    #     values = sel.xpath(par.replace(node, '')).extract()
                    # else:
                    # 修改逻辑，只有一个输出值的时候
                    values = sel.xpath(par.replace(node, '')).extract_first()
                    values = values if values else ''

                if algo:
                    values = JsFunc(algo, values).__call__()

                for pa in finalout['data']:
                    if code == pa['code']:
                        tdict = {"code":code,"value":re_text(str(values))}
                        param.append(tdict)

                url = url.replace('{%s}' % code, re_text(str(values)))

            if parm:
                for p_ in parm:
                    url = url.replace('[%s]' %p_, re_text(str(parm[p_])))
                    param.append({"code":p_,"value":re_text(parm[p_])})

            grad['URL_'] = url
            #grad['url'] = meta['p_url']
            grad['PARAM_'] = param
            grad['DEALTIME_'] = str(time.time())
            grad['ENTITY_NAME_'] = entity_name
            grad['ENTITY_CODE_'] = entity_code
            #grad['template_code'] = self.code_
            unit.append(grad)
            grad = eval(str(grad))
            grad['STATUS_'] = '1'
            grad['LOCKTIME_'] = ''
            grad['DEALTIME_'] = str(time.time())
            unit.append(grad)
            final.append(unit)

        self.__import_data(final)
        self.address_mongodb.R_Mongodb({'URL_': p_url})

    def __import_data(self, final):
        for x, y in final:
            # print(x,y)
            # 入mongodb
            try:
                # b_w = Black_White().prevent_outer_chain(x['url'],self.white,self.black)
                # if b_w is None:
                #     self.log.error('%s不在黑白名单内' %x['url'])
                #     self.gray_url = self.gray_url + 1
                #     continue
                # if not b_w:
                #     self.log.error('%s在黑名单内' % x['url'])
                #     self.black_url = self.black_url + 1
                #     continue
                status = self.mongodb.I_Mongodb(x)
                if status != 'duplicate':
                    self.tempmongodb.I_Mongodb(y)
                    self.success = self.success + 1
                else:
                    self.duplicate = self.duplicate + 1
            except Exception as e:
                #self.log.error(e)
                pass