# encoding: utf-8
import os
from scrapy import cmdline

from ICrawlerSpiders.Spiders.BaiduSpider import Baidu
from ICrawlerSpiders.Spiders.MeiPianContentSpider import MeiPian_Content_Start
from OperateDB import OPMysql
from SpidersLog.ICrwlerLog import ICrawlerLog
from ICrawlerSpiders.Spiders.ContentTempletSpider import Content_Start
from Env import LogVariable as lv
from ICrawlerSpiders.Spiders.SinaWeiboSpider import WeiBoSpider
from ICrawlerSpiders.Spiders.SougouWechatSpider import WechatSpider
import sys
import traceback

# entity_name = '成都信用工商网站'
# entity_code = 'BAIDU_ABCActivity'  # YFWHOSPITAL
# address_code = 'BAIDU_ABCActivity.ADDR'
# method = 'SPIDER_ADDRESS'
# # method = 'SPIDER_CONTENT'
# jobinst_id = 'None'
# fire_time = '1538150400423'
# job_code = 'None'
from VERSION import VERSION_NUMBER


def Begin():
    method = sys.argv[1]
    # job_code = sys.argv[2]
    entity_code = sys.argv[2]
    jobinst_id = sys.argv[3]
    fire_time = sys.argv[4]
    address_code = sys.argv[5]

    log.info('当前实体{}运行的版本为：{}'.format(str(entity_code), str(VERSION_NUMBER)))

    #lv.set_job_code(job_code)
    lv.set_job_code(entity_code)
    lv.set_jobinst_id(jobinst_id)
    lv.set_group_code(method)
    lv.set_fire_time(fire_time)
    lv.set_address_code(address_code)

    opmysql = OPMysql.Op_Mysql()

    try:
        log.info(102)
        data = opmysql.Select_Query(output=['NAME_','TYPE_','CONFIG_'], tablename='spi_scra_entity', where='CODE_="%s"' % entity_code)[0]
        log.info(103)
    except:
        log.info(104)
        log.error('传入实体code错误')
        print(8)
        return False

    Tpye = opmysql.Select_Query(output='TYPE_', tablename='spi_scra_addr', where='CODE_="%s"' % address_code)
    log.info(105)

    if isinstance(Tpye,list):
        log.info(106)
        Tpye = Tpye[0]
    log.info(107)
    entity_name = data[0]
    dbanme = data[1]
    TYPE_ = data[1]
    parent_id = opmysql.Select_Query(output='PARENT_ID_', tablename='spi_entity_type',where='CODE_="%s"' % dbanme)
    log.info(108)
    if isinstance(parent_id,list):
        log.info(109)
        parent_id = parent_id[0]
    if parent_id:
        log.info(110)
        dbanme = dbanme + '_' + parent_id
    config = eval(data[2])

    log.info('爬虫开始执行')
    log.info('爬虫选取实体code：%s' % entity_code)

    if config['entityType'] == 'weChat':
        log.info(111)
        WechatSpider().query_code(code=config['id'],entity_code=entity_code,entity_name=entity_name)
        log.info(112)
        print(0)

    elif config['entityType'] == 'weibo':
        log.info(113)
        WeiBoSpider(url=config['id'], entity_code=entity_code, entity_name=entity_name).query_code()
        log.info(114)
        print(0)

    # 百度搜索
    elif 'BAIDU_' in entity_code:
        Baidu(code=address_code,
              entity_code=entity_code,
              entity_name=entity_name
              ).main()
        print(0)

    else:
        log.info(115)
        if method == 'SPIDER_ADDRESS':

            if not Tpye:
                log.error('传入地址code错误')
                print(8)
                return False
            log.info(116)
            type_ = opmysql.Select_Query( output='TYPE_', tablename='spi_scra_addr',where='CODE_="%s"' % address_code)[0]

            if not type_:
                log.info(117)
                print(8)
                log.error('传入地址code错误')
                return False

            if type_ == 'GRAB':
                log.info(118)
                key = get_key(address_code,opmysql)
            else:
                log.info(119)
                key = 'URL_'
            log.info(120)
            spidername = 'AddressTempletSpider'
            line = 'scrapy crawl %s -a code_=%s -a type_=%s -a entity_code=%s -a entity_name=%s -a dbname=%s ' \
                   '-a key=%s -L WARNING' % (spidername, address_code, type_, entity_code, entity_name, dbanme, key)
            log.info(line)
            log.info(121)
            cmdline.execute(line.split())
            log.info(122)

        if method == 'SPIDER_CONTENT':
            log.info(123)
            code = opmysql.Select_Query('spi_scra_content','CODE_','ENTITY_CODE_="%s"' % entity_code)
            if not code:
                log.info(124)
                log.error('没有该内容code')
                print(8)
                return False
            log.info(125)
            key = 'null'
            type_ = []
            for c in code:
               log.info(126)
               type1_ = opmysql.Select_Query('spi_scra_content_item','TYPE1_','CONTENT_CODE_="%s" and '
                                             'TYPE1_!="MAPPING" and TYPE1_!="PARAM" and TYPE1_!="SUB"' % c)
               if type1_:
                   log.info(127)
                   if isinstance(type1_,list):
                       for i in set(type1_):
                           type_.append(i)
                   else:
                       log.info(128)
                       type_.append(type1_)

            type_ = list(set(type_))
            log.info(128)
            spidername = 'ContentTempletSpider'

            if type_ is None:
                type_ = 'ALL'

            if isinstance(type_,list):
                type_ = ','.join(type_)

            if isinstance(code,list):
                code = ','.join(code)
                # 调用美篇内容
                if entity_code == 'meipian':
                    MeiPian_Content_Start(code_=code,
                                          type_=type_,
                                          entity_code=entity_code,
                                          entity_name=entity_name,
                                          dbname=dbanme,
                                          method=method,
                                          key=key).start_requests()
                else:
                    Content_Start(code_=code,
                                  type_=type_,
                                  entity_code=entity_code,
                                  entity_name=entity_name,
                                  dbname=dbanme,
                                  method=method,
                                  key=key).start_requests()




def get_key(code,op):
    log.info(131)
    grab_id = op.Select_Query('spi_scra_addr', 'GRAB_ID_', 'CODE_="%s"' % code)[0]
    config = op.Select_Query('spi_grab_config', 'CONFIG_', 'ID_="%s"' % grab_id)[0]
    out_put = eval(config)['output']['data']
    for o_ in out_put:
        if 'keyParam' in o_ and o_['keyParam'] == 'Y':
            return o_['code']
    log.info(132)
    return 'URL_'


def run():
    try:
        log.info('爬虫开始运行---')
        Begin()
    except Exception as e:
        # traceback.print_exc()
        # print(e)
        log.error('爬虫遇到异常失败')
        log.error(e)
        return False
        # print(5)


if __name__ == '__main__':
    log = ICrawlerLog('spider').save

    run()