# encoding: utf-8
from SpiderTools import OCR
from SpiderTools.Tool import get_dict
from SpiderTools.GetWord import get_word_content
from SpiderTools.Tool import complement_url
from SpiderTools.Tool import re_text
from SpiderTools.Tool import deal_text
from SpiderTools.Tool import Download
from SpiderTools.Tool import replace_special_text
from SpiderTools.Tool import deal_img_special_symbol
from SpiderTools.Tool import get_date_time
from SpiderTools.PDF import PDF
from scrapy.selector import Selector
from pyquery import PyQuery
from SpidersLog.ICrwlerLog import ICrawlerLog
from SpiderTools.JsFunc import JsFunc
from SpiderTools.Tool import get_base64
from staticparm import img_dir
from staticparm import pdf_dir
from staticparm import word_dir
import time
import re

class Page_Parse:

    def __init__(self):

        self.log = ICrawlerLog('spider').save

    def page_content_parse(self,content_data, meta):
        '''page模式解析网页内容
        :param response: 网页的response信息
        '''

        def __get_content(group, type_):
            '''xpath解析
            :param group: xpath组
            :param type_: 文本类型
            :return: 返回xpath得到的信内容
            '''
            response = Selector(text=content_data)
            content = ''
            for tt_ in group:
                if tt_ == '':
                    return None
                if type_ == 'TEXT':
                    if '/text()' not in tt_ and '@' != tt_.split('/')[-1][0]:
                        tt_ = tt_ + '/text()'
                    content = ''.join(response.xpath(tt_).extract())
                if type_ == 'FILE'or type_ =='IMGURL' or type_ =='IMG' or type_ == 'URL':
                    content = response.xpath(tt_).extract_first()
                if type_ == 'IMGOCR' :
                    content = response.xpath(tt_).extract()
                if type_ == 'BLOB':
                    style = re.findall('(<(?:script|style)[\s\S]*?>[\s\S]*?<(?:\/script|\/style)>)', content_data)
                    for s_ in style:
                        content_data.replace(s_, '')
                    response = Selector(text=content_data)
                    content = '|'.join(response.xpath(tt_.replace('/text()', '') + '//text()').extract())
                    # if content:
                    #     # 去掉样式标签
                    #     content = PyQuery(content)
                    #     content.find('script').remove()
                    #     content.find('style').remove()
                    #     content = content.text()
                    # else:
                    #     content = None

                if not content:
                    continue
                else:
                    break
            return content

        flag = 0
        pattern = meta['pattern']
        text_date = ''
        imgocr = []
        img = []
        longtext = []
        imgurl = []
        ttxt = []
        word = []
        pdf = []
        yv = []
        child_url = []
        finalout = eval(pattern[0]['con_f']) # 输出项
        final_list = []
        entity_name = meta['entity_name']
        entity_code = meta['entity_code']
        content_code = meta['content_code']
        algo = meta['algo']
        child_xpath = meta['child_xpath']
        child_prefix = meta['child_prefix']
        url = meta['url']

        # 循环拿出类型为IMGOCR和LONGTEXT等各个类型的项
        for p_ in pattern:
            if p_['type2'] == 'TEXT':
                ttxt.append(p_)
            if p_['type2'] == 'IMGOCR':
                imgocr.append(p_)
            if p_['type2'] == 'IMGURL':
                imgurl.append(p_)
            if p_['type2'] == 'IMG':
                img.append(p_)
            if p_['type2'] == 'BLOB':
                longtext.append(p_)
            if p_['type2'] == 'FILE':
                if p_['datatype'] == 'WORD':
                    word.append(p_)
                if p_['datatype'] == 'PDF':
                    pdf.append(p_)
            # 存放必填数据信息
            if p_['required'] == 'Y':
                yv.append(p_['code'].split('.')[-1])

        #出来子模板xpath
        for c_x,c_p in list(zip(child_xpath,child_prefix)):
            c_url = __get_content([c_x], 'URL')
            if c_p:
                c_url = c_p + c_url
            child_url.append(c_url)

        # 处理文本类
        for t_ in ttxt:
            content = __get_content(t_['pattern'], t_['type2'])
            code = t_['code'].replace(content_code + '.', '')

            if not content:
                finalout[code] = ''
                continue

            if code in algo:
                finalout[code] = JsFunc(algo[code], content).text
            else:
                finalout[code] = re_text(content)

        for im in img:
            content = __get_content(im['pattern'], im['type2'])
            code = im['code'].replace(content_code + '.', '')

            if not content:
                finalout[code] = ''
                continue

            name = im['code'].split('.')[-1]
            if name in algo:
                content = JsFunc(algo[name], content).text

            img_name = deal_img_special_symbol(content.split('/')[-1])  # 分析拿到的图片地址信息，截取图片的名称
            img_url = complement_url(meta['url'], content)
            try:
                Download(img_url, img_dir, img_name)
            except Exception as e:
                self.log.error('下载图片错误，可能是配置问题, img url: %s,保存名字为:%s' % (img_url,img_name))
                self.log.error(e)
                return False

            img_base = get_base64(img_dir, img_name)

            finalout[code] = img_base

        for iu_ in imgurl:
            content = __get_content(iu_['pattern'], iu_['type2'])
            code = iu_['code'].replace(content_code + '.', '')

            if not content:  # 当拿到的值为空时，跳出这一层
                finalout[code] = ''
                continue

            name = iu_['code'].split('.')[-1]
            if name in algo:
                content = JsFunc(algo[name], content).text

            img_name = deal_img_special_symbol(content.split('/')[-1])  # 分析拿到的图片地址信息，截取图片的名称
            img_url = complement_url(meta['url'], content)
            try:
                Download(img_url, img_dir, img_name)
            except Exception as e:
                self.log.error('下载图片错误，可能是配置问题, img url: %s,保存名字为:%s' % (img_url, img_name))
                self.log.error(e)
                return False

            finalout[code] = img_url

        # 处理图片类
        for i_ in imgocr:
            content = __get_content(i_['pattern'], i_['type2'])  # 通过xpath拿到图片的地址信息
            code = i_['code'].replace(content_code + '.', '')

            if not content:  # 当拿到的值为空时，跳出这一层
                finalout[code] = ''
                continue

            big_img_data = ''
            img_base64 = []
            for img_url in content:
                name = i_['code'].split('.')[-1]
                if name in algo:
                    img_url = JsFunc(algo[name], img_url).text
                img_name = deal_img_special_symbol(img_url.split('/')[-1])  # 分析拿到的图片地址信息，截取图片的名称
                img_url = complement_url(meta['url'], img_url)
                try:
                    Download(img_url, img_dir, img_name)
                except Exception as e:
                    self.log.error('下载图片错误，可能是配置问题, img url: %s,保存名字为:%s' % (img_url, img_name))
                    self.log.error(e)
                    #return False
                    continue

                base64_data, img_content = OCR.ocr(img_dir, img_name)  # 进行OCR识别，拿到base64和图片内容信息的值
                # if img_content is None:
                #     return None
                img_base64.append(base64_data)
                big_img_data = big_img_data + img_content

            finalout[code] = big_img_data
            if i_['expr']:
                tempdict = get_dict(i_['expr'][code], big_img_data)
                finalout.update(tempdict)
        #     finalout['URL_'] = meta['url']
        #     finalout['DEALTIME_'] = str(time.time())
        #     finalout['DATETIME_'] = get_date_time()
        #     finalout['ENTITY_NAME_'] = entity_name
        #     finalout['ENTITY_CODE_'] = entity_code
        #
        #     if i_['expr']:
        #         tempdict = get_dict(i_['expr'][code], big_img_data)
        #         finalout.update(tempdict)
        #
        #     final_list.append(finalout)
        #
        #     flag = 1
        #
        # if flag == 1:
        #     self.log.info('%s,图片识别完成' %meta['url'])
        #     return final_list

        # 处理大文本类型
        for l_ in longtext:
            content = __get_content(l_['pattern'], l_['type2'])
            code = l_['code'].replace(content_code + '.', '')

            # if not content and l_['required'] == 'Y':
            #     self.log.error('大文本xpath有问题,返回内容为空，请检查有问题字段%s' %l_['code'])
            #     return False

            if not content:
                finalout[code] = ''
                continue

            # content = response.xpath(l_[2][0]).xpath('string()').re('(\w+)') #这个方式排版会有问题
            # text_date = ''.join(content).strip('\r\n').strip('\r').strip('\n').strip().strip(' ')
            text_date = ''.join(content)

            temp_text = []
            for c_ in content:
                temp_text.append(deal_text(c_))

            textdata = replace_special_text(''.join(temp_text))

            finalout[code] = textdata

            if l_['expr']:
                tempdict = get_dict(l_['expr'][code], text_date)
                finalout.update(tempdict)

            if code in algo:
                finalout[code] = JsFunc(algo[code],textdata).text

        # 处理word类型
        for w_ in word:
            file_url = __get_content(w_['pattern'], w_['type2'])
            code = w_['code'].replace(content_code + '.', '')

            if not file_url:
                finalout[code] = ''
                continue

            name = entity_code + '_' + file_url.split('/')[-1]

            if file_url:
                file_url = complement_url(meta['url'], file_url)

            try:
                Download(file_url, word_dir, name)
            except Exception as e:
                self.log.error('下载word错误,word url: %s' % file_url)
                self.log.error(e)
                return False

            word_content = get_word_content(word_dir, name)

            finalout[code] = word_content

            if w_['expr']:
                tempdict = get_dict(w_['expr'][code], word_content)
                finalout.update(tempdict)

        # 处理pdf类型
        for p_ in pdf:
            pdf_url = __get_content(p_['pattern'], p_['type2'])
            code = p_['code'].replace(content_code + '.', '')

            if not pdf_url:
                finalout[code] = ''
                continue

            if pdf_url:
                complement_url(meta['url'], pdf_url)

            pdf_content = PDF.get_pdf_content(pdf_url)

            finalout[code] = pdf_content

            if p_['expr']:
                tempdict = get_dict(p_['expr'][code], pdf_content)
                finalout.update(tempdict)

        # 组装其它信息并返回
        if isinstance(finalout, str):
            finalout = eval(finalout)
        finalout['URL_'] = meta['url']
        finalout['DEALTIME_'] = str(time.time())
        finalout['DATETIME_'] = get_date_time()
        finalout['ENTITY_NAME_'] = entity_name
        finalout['ENTITY_CODE_'] = entity_code
        final_list.append(finalout)
        final_list.append(yv)

        # if text_date != '' :
        return final_list,child_url