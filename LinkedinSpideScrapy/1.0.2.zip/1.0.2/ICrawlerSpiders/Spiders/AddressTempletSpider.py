# encoding: utf-8
from scrapy.spidermiddlewares.httperror import HttpError
#from ICrawlerSpiders.useragent import user_agent_list
from twisted.internet.error import DNSLookupError
from twisted.internet.error import TimeoutError,TCPTimedOutError,ConnectionRefusedError
#from functools import reduce
from OperateDB.OpMongodb import Op_MongoDB
from OperateDB.OpRedis import RedisClient
from SpiderTools.Tool import get_jp_value
from SpiderTools.Tool import re_text
from SpiderTools.Tool import complement_url
from SpiderTools.Tool import get_date_time
from Env.ParseYaml import DBConfigParser
from TemplateMiddleware.AddresMiddlewares import Address_Middleware
from SpidersLog.ICrwlerLog import ICrawlerLog
from Env.BlackWhite import Black_White
from scrapy.selector import Selector
from SpiderTools.JsFunc import JsFunc
#from IPProxy.IPProxy import IPProxy
from staticparm import max_duplicate
import demjson
#import execjs
#import requests
import json
import scrapy.crawler
import ssl
import time
import jsonpath
import scrapy

ssl._create_default_https_context = ssl._create_unverified_context

class A_Templet_Spiders(scrapy.Spider):

       name = 'AddressTempletSpider'
       #allowed_domains = ["chinaz.com"]
       #start_urls = ['https://www.cdcredit.gov.cn']
       success = 0
       total = 0
       duplicate = 0
       black_url = 0
       gray_url = 0
       entity = ''
       s_code = ['PSBCORGANIZE']

       def __init__(self,code_,type_,entity_code,entity_name,key,*args,**kwargs):
           '''定义参数
           :param code_: code
           :param type_: content还是grab
           :param entity_code: 实体code
           :param entity_name: 实体名称
           :param dbname:
           :param jobinstid: job调度id
           :param method: get还是post
           :param args:
           :param kwargs:
           '''
           super(A_Templet_Spiders, self).__init__(*args, **kwargs)
           self.code_ = code_
           self.type_ = type_
           self.entity_code = entity_code
           self.entity = entity_code
           self.entity_name = entity_name
           self.key = key

           config = DBConfigParser()
           fixed_db = config.get_fixed_db()
           temp_db = config.get_temp_db()

           self.mongodb = Op_MongoDB(db=fixed_db, coll=entity_code,key=key)
           self.tempmongodb = Op_MongoDB(db=temp_db, coll=entity_code,key=key)
           self.address_mongodb = Op_MongoDB(db='spider_address', coll=code_)

       def start_requests(self):

           try:
               midd = Address_Middleware(self.code_).Invoking_Diff()
               if not midd:
                   self.log.error('地址中间件返回False')
                   print(1)
                   raise  Exception('地址中间件返回False')
           except Exception as e:
               log = ICrawlerLog(name='middleware').save
               log.error('%s' %e)
               print(1)
               raise  Exception('地址中间件执行异常')

           self.log = ICrawlerLog(name='spider').save
           self.log.info('地址中间件程序执行成功')
           self.white = midd['white']
           self.black = midd['black']
           address_url = []

           if self.type_ != "FIXED":

               address_url = self.address_mongodb.S_Mongodb()

               if not address_url:
                   self.address_mongodb.I_Mongodb([{'URL_': m_} for m_ in midd['url']])

               address_url = self.address_mongodb.S_Mongodb(output='URL_')

           if self.type_ == "GRAB":
               #refdb = midd['db']
               pform = midd['parm']
               purl = midd['url']
               pheaders = midd['header']
               pmethod = midd['method']
               param_type = midd['param_type']
               v_parm = ''

               meta = {"v_parm": '',
                       "final_out": midd['final_out'],
                       "con_out": midd['content_out'],
                       "textType": midd['textType'],
                       "node": midd['node'],
                       "entity_name": self.entity_name,
                       "entity_code": self.entity_code,
                       "domain": midd['domain'],
                       "content_url": midd['content_url'],
                       "content_algo": midd['content_algo'],
                       "param_output": midd['param_output'],
                       "result_output": midd['result_output'],
                       }

               # # 等价于 lambda x,y: y in x and x or x+[y] 。去重result
               # func = lambda x, y: x if y in x else x + [y]
               #
               # result = reduce(func, [[], ] + result)

               request_map = []

               if len(pform) ==  len(purl):
                   for url in purl:
                       index = purl.index(url)
                       form = pform[index]
                       request_map.append((url, form))
               elif len(pform) == 0:
                   for url in purl:
                        request_map.append((url, None))
               else:
                   for form in pform:
                       for url in purl:
                           request_map.append((url,form))

               for rm in request_map:
                   url = rm[0]
                   form = rm[1]
                   meta['parm'] = form
                   meta['p_url'] = url

                   if url not in address_url:
                       continue
                   if self.duplicate < int(max_duplicate):
                       if param_type == 'PAYLOAD':
                           bodys = json.dumps(form)
                           yield scrapy.Request(
                               url=url, headers=pheaders, method=pmethod, meta=meta, body=bodys,
                               callback=self.grad_adress_parse, dont_filter=True,
                               errback=lambda respone, arg2=v_parm: self.errback_httpbin(respone, v_parm)
                           )
                       elif self.entity_code == 'meipian':
                           import requests
                           # app地址请求
                           del pheaders['User-Agent']
                           jsontext = json.loads(form['param'])
                           try:
                               res = requests.request(method=pmethod, url=url, headers=pheaders, json=jsontext,
                                                      proxies=self.ip_proxy(), verify=False)
                           except Exception as e:
                               self.log.error(e.args)
                               self.log.error('美篇地址请求错误！')
                               return False
                           if res.json().get("articles"):
                               self.__grad_parse(res, res.text, meta)
                           else:
                               print(1)
                               self.log.error('请求头和请求参数配置错误！')
                               return False
                       else:
                           yield scrapy.FormRequest(
                               url=url, headers=pheaders, formdata=form, method=pmethod, meta=meta,
                               callback=self.grad_adress_parse, dont_filter=True,
                               errback=lambda respone, arg2=v_parm: self.errback_httpbin(respone, v_parm)
                           )

           if self.type_ == 'PAGE':
               urllist = midd['url']

               for p_url in urllist:
                   if p_url not in address_url:
                       continue

                   if self.duplicate < max_duplicate:
                       yield scrapy.Request(url=p_url, callback=self.page_adress_parse, encoding='utf-8',
                                            meta={'pattern': midd['pattern'],'prefix_url': midd['prefix_url'],
                                                  'prefix_expr' : midd['prefix_expr'],
                                                  'entity_name' : self.entity_name,
                                                  'entity_code' : self.entity_code,
                                                  'domain':midd['domain'],
                                                  'algo':midd['algo'],
                                                  'p_url':p_url
                                                  }
                                            , errback=lambda respone, arg2=p_url: self.errback_httpbin(respone,arg2)
                                            )

           if self.type_ == 'FIXED':
               final = []
               for url in midd['url']:
                   fixed = {}
                   final.append(self.__assembly(fixed,url))
               self.__import_data(final)

       def grad_adress_parse(self, response):
           '''地址抓包模式解析并入库
           :param response:
           :return:
           '''
           v_parm = response.meta['v_parm']
           response_content = response.body
           self.__grad_parse(response,response_content,response.meta)

       def page_adress_parse(self, response):
           '''地址page模式内容处理并入库
           :param response:
           '''
           #print(response.meta['proxy'])
           pattern = response.meta['pattern']
           prefix_url = response.meta['prefix_url']
           algo = response.meta['algo']
           final = []

           data = []
           #内容解析
           for p_ in pattern:
               if len(p_) != 2:
                   continue
               for p1_ in p_:
                   temdata = []
                   if p1_ is None or p1_ == '':
                       continue
                   v = response.xpath(p1_).extract()

                   if v is None or len(v) < 1:
                       continue
                   else:
                       for n in v:
                           temdata.append(n)
                   data.append(temdata)
               if len(data) == 2:
                   break

           if len(data) != 2:
               self.log.error('url=%s page模式未匹配到数据,xpath=%s' %(response.url,pattern))
               return None

           for url, name in list(zip(*data)):
               address = {}
               if algo:
                   url = JsFunc(algo,"%s" %url).text
                   if not url:
                       self.log.error('algo中js匹配url出错')
                       raise Exception('algo中js匹配url出错')

               #补全url地址
               if prefix_url and algo:
                   url = prefix_url + url
               else:
                   url = complement_url(response.url,url,prefix_url)

               if not url:
                   self.log.error('url为空，不插入')
                   continue

               #地址信息入库
               address['NAME_'] = re_text(name)
               final.append(self.__assembly(address,url))

           self.__import_data(final)
           self.address_mongodb.R_Mongodb({'URL_': response.meta['p_url']})

       def __import_data(self,final):
           for x,y in final:
               #print(x,y)
               #入mongodb
               try:
                   b_w = Black_White().prevent_outer_chain(x['URL_'],self.white,self.black)
                   if b_w is None:
                       self.log.error('%s不在黑白名单内' %x['URL_'])
                       self.gray_url = self.gray_url + 1
                       continue
                   if not b_w:
                       self.log.error('%s在黑名单内' % x['URL_'])
                       self.black_url = self.black_url + 1
                       continue
                   if not x[self.key]:
                       self.log.error(x)
                       self.log.error('主键为空，不插入')
                       continue
                   status = self.mongodb.I_Mongodb(x)
                   if status != 'duplicate':
                       self.tempmongodb.I_Mongodb(y)
                       self.success = self.success + 1
                   elif status == 'duplicate':
                       self.duplicate = self.duplicate + 1
               except Exception as e:
                   self.log.error(e)
           self.total = self.total + len(final)

       def errback_httpbin(self, failure,name):
           '''
           异常输出
           :param failure:
           :param name:
           :return:
           '''
           # Logs all failures

           # in case you want to do something special for some errors,
           # you may need the failure's type:
           if failure.check(ConnectionRefusedError):
               request = failure.request
               self.log.error('ConnectionRefusedError on %s' % (request.url))

           elif failure.check(HttpError):
               # these exceptions come from HttpError spider middleware
               # you can get the non-200 response
               response = failure.value.response
               self.log.error('HttpError on %s satus_code:%s' %(response.url,response.status))

           elif failure.check(DNSLookupError):
               # this is the original request
               request = failure.request
               self.log.error('DNSLookupError on %s', request.url)

           elif failure.check(TimeoutError, TCPTimedOutError):
               #print('111',failure.value.response)
               request = failure.request
               self.log.error('TimeoutError on %s', request.url)
               #self.logger.error('TimeoutError on %s', request.url)
           else:
               request = failure.request
               self.log.error('OtherError on %s', request.url)
               self.log.error(repr(failure))

       def close(spider, reason):
           log = ICrawlerLog(name='spider').save
           if spider.total != 0 or spider.duplicate != 0 or spider.success != 0:
               log.info('地址模板%s执行成功 ' % spider.entity)
               log.info('总共抓取%s条,成功抓取%s条,重复抓取%s条,黑名单%s条，灰名单%s条'
                        %(spider.total, spider.success, spider.duplicate,spider.black_url,spider.gray_url))
               print(0)
           else:
               log.error('执行异常')
               spider.address_mongodb.R_Mongodb({})
               print(5)


       def grad_adress_parse_temp(self, response,meta):
           '''地址抓包模式解析并入库
           :param response:
           :return:
           '''
           v_parm = meta['v_parm']
           response_content = response.content
           self.__grad_parse(response,response_content,meta)


       def __assembly(self,data,url):
           unit = []
           data['URL_'] = url
           data['DEALTIME_'] = str(time.time())
           data['ENTITY_NAME_'] = self.entity_name
           data['ENTITY_CODE_'] = self.entity_code
           data['TEMPLATE_CODE_'] = self.code_
           unit.append(data)
           grad = eval(str(data))
           grad['STATUS_'] = '1'
           grad['LOCKTIME_'] = ''
           grad['DEALTIME_'] = str(time.time())
           grad['DATETIME_'] = get_date_time()
           unit.append(grad)
           return unit

       def __grad_parse(self,response,response_content,meta):

           text_type = meta['textType']
           node = meta['node']
           content_url = meta['content_url']
           p_url = meta['p_url']
           content_algo = meta['content_algo']
           parm = meta['parm']
           param_output = meta['param_output']
           result_output = meta['result_output']
           con_out = meta['con_out']

           final = []

           try:
               content_data = str(response_content, encoding='utf-8')
           except:
               encode = response.encoding

               if encode == 'ISO-8859-1' or encode == 'cp1252':
                   encode = 'gb2312'

               try:
                   content_data = str(response_content, encoding=encode)
               except:
                   if self.entity_code == 'meipian':
                       content_data = response.json()
                   else:
                       content_data = response.text

           if not content_data and len(content_data) < 10:
               self.address_mongodb.R_Mongodb({'URL_': p_url})
               self.log.error('去请求网站返回数据为空,url:%s' % p_url)
               return False

           if text_type != 'html':
               try:
                   content_data = demjson.decode(content_data)
               except:
                   content_data = content_data

           if content_algo:
               try:
                  js_data = JsFunc(content_algo, content_data).text
                  if isinstance(js_data,dict) or isinstance(js_data,list):
                      content_data  = js_data
                  else:
                      try:
                          content_data = eval(js_data)
                      except:
                          content_data = demjson.decode(js_data)
               except:
                   self.log.error('处理异常')
                   return False

           if isinstance(content_data,list):
               node = ''

           if node:
               if text_type == 'json':
                   content = jsonpath.jsonpath(content_data, node)
                   if not content:
                       try:
                           content = jsonpath.jsonpath(content_data, node[:-3])[0]
                       except:
                           self.log.error('json数据匹配异常')
                           return False
                       if not content:
                           self.log.error('地址抓包没有匹配到数据')
                           return False
                       content = eval(content)
                   content_data = content
               elif text_type == 'html':
                   response_data = Selector(text=content_data)
                   if node[-1] == '/' and node[-2] == '/':
                       node = node[:-2]
                       content_data = response_data.xpath(node)
                   else:
                       content_data = response_data.xpath(node[:-1])
           else:
               if isinstance(content_data, str):
                   if content_data[0] == '[':
                       if content_data[-1] != ']':
                           content_data = content_data + ']'
                       content_data = eval(content_data)
                   else:
                       response_data = Selector(text=content_data)
                       content_data = [response_data]
               elif isinstance(content_data, dict):
                   content_data = [content_data]

           if not content_data:
               self.address_mongodb.R_Mongodb({'URL_': p_url})
               self.log.error('地址抓包内容经过处理后值为空，请检查问题,url:%s' %p_url)
               return False

           con_data = jsonpath.jsonpath(con_out, '$.data[?(@)]')
           con_data = con_data if con_data else con_out if isinstance(con_out,list) else [con_out]

           # 挂包内容解析
           for sel in content_data:
               url = content_url
               grad = {}
               param = []
               for item in con_data:
                   code = item['code']
                   par = item['expr']

                   if 'itemType' in item and item['itemType'] == 'paramOutput':
                       continue

                   if 'algo' in item:
                       algo = item['algo']
                   else:
                       algo = ''

                   if text_type == 'json':

                       if '$.' in par or '.' in par:
                           values = get_jp_value(sel, par)
                           if values:
                               values = values
                           else:
                               values = ''
                       else:
                           try:
                               values = sel[par]
                           except:
                               values = ''
                       if isinstance(values, list) and len(con_data) > 1:
                           for i in range(len(values)):
                               if not isinstance(values[i],str):
                                   values[i] = str(values[i])
                           values = ','.join(values) if len(values) > 0 else ''

                   elif text_type == 'html':
                       if len(con_data) == 1:
                           values = sel.xpath(par.replace(node, '')).extract()
                       else:
                           values = sel.xpath(par.replace(node, '')).extract_first()
                           values = re_text(values) if values else ''

                   if len(con_data) > 1:
                       if algo:
                           values = JsFunc(algo, values).text

                       tdict = {"code": code, "value": re_text(str(values))}
                       param.append(tdict)

                       if code == self.key:
                           grad[code] = re_text(str(values))

                       url = url.replace('{%s}' % code, re_text(str(values)))
                   else:
                       for v_ in values:
                           grad = {}
                           if algo:
                               v_ = JsFunc(algo, v_).text
                           url_ = url.replace('{%s}' % code, re_text(str(v_)))
                           tdict = {"code": code, "value": re_text(str(v_))}
                           grad['PARAM_'] = [tdict]
                           if code == self.key:
                               grad[code] = re_text(str(v_))
                           for po in param_output:
                               if po['code'] == self.key:
                                   grad[po['code']] = re_text(str(parm[po['expr']]))
                               url = url.replace('{%s}' % po['code'], re_text(str(parm[po['expr']])))
                               grad['PARAM_'] = [{"code": po['code'], "value": re_text(parm[po['expr']])}]
                           final.append(self.__assembly(grad, url_))

               if len(con_data) > 1:
                   for po in  param_output:
                       if po['code'] == self.key:
                           grad[po['code']] = re_text(str(parm[po['expr']]))
                       url = url.replace('{%s}' % po['code'], re_text(str(parm[po['expr']])))
                       param.append({"code": po['code'], "value": re_text(parm[po['expr']])})

                   if not url:
                       self.log.error('url为空，不插入,param:%s' %param)
                       continue

                   grad['PARAM_'] = param
                   final.append(self.__assembly(grad, url))

           self.__import_data(final)
           self.address_mongodb.R_Mongodb({'URL_': p_url})

       def ip_proxy(self):
           log = ICrawlerLog(name='spider').save
           try:
               # redis代理池
               ip = RedisClient().get()
               log.info('当前使用ip为%s' % ip)
               proxies = {
                   'http': 'http://' + ip,
                   'https': 'https://' + ip
               }
               return proxies
           except Exception as e:
               log.error(e.args)
               print(6)
               return False