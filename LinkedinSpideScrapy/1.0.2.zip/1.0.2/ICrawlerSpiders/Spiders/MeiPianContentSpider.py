# encoding: utf-8
import os
import re

from OperateDB.OpMongodb import Op_MongoDB
from OperateDB.OpRedis import RedisClient
from SpidersLog.ICrwlerLog import ICrawlerLog
from TemplateMiddleware.ContentMidlewares import Content_Middleware
from bson.objectid import ObjectId
from Exception.HttpCode import HttpCode
from Env.ParseYaml import DBConfigParser, FileConfigParser
from ICrawlerSpiders.useragent import user_agent_list
from ICrawlerSpiders.DataParse.GrabParse import Grad_Parse
from ICrawlerSpiders.DataParse.PageParse import Page_Parse
from SpiderTools.Tool import get_date_time, Download, platform_system
from SpiderTools.Tool import get_jp_value
from IPProxy.IPProxy import IPProxy
from SpiderTools.DealPdf import PDF
from SpiderTools.Tool import get_dict
from staticparm import pdf_dir, root_path
from SpiderTools.Tool import get_base64
import random
import ssl
import time
import requests

# path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))

# root_path = os.path.normpath(os.path.join(path, os.pardir))

ssl._create_default_https_context = ssl._create_unverified_context

# 这句是不让它报这个警告错误
# [py.warnings] WARNING: D:\Python35\lib\site-packages\urllib3\connectionpool.py:858:
# InsecureRequestWarning: Unverified HTTPS request is being made.
# Adding certificate verification is strongly advised.
# See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
requests.packages.urllib3.disable_warnings()


class C_Templet_Spdiers:

    # name ='ContentTempletSpider'

    def __init__(self, code_, type_, entity_code, entity_name, dbname, method, key, *args, **kwargs):
        super(C_Templet_Spdiers, self).__init__(*args, **kwargs)
        self.code_ = code_
        self.type_ = type_
        self.entity_code = entity_code
        self.entity_name = entity_name
        self.dbname = dbname
        self.method = method

        # self.parm = list(zip(code_.split(','), type_.split(',')))
        self.code_ = code_.split(',')
        if isinstance(self.code_, str):
            self.code_ = [self.code_]
        # 获取collections全局变量
        config = DBConfigParser()
        temp_db = config.get_temp_db()
        self.data_db = config.get_data_db()
        # 存储内容数据
        self.data_mongodb = Op_MongoDB(db=self.data_db, coll=dbname, key='null')
        self.op_key = Op_MongoDB(db=self.data_db, coll=str(dbname) + '_KEY_', key='URL_')
        # 获取内容url并删除该表中已经获取内容数据的实体url
        self.temp_mongodb = Op_MongoDB(db=temp_db, coll=entity_code, key='null')
        self.log = ICrawlerLog('spider').save

    def u_data(self, id, status):
        '''更改数据状态
        :param id: 数据id
        :param status: 状态值
        :return:
        '''
        self.temp_mongodb.U_Mongodb({"_id": ObjectId(id)},
                                    {"$set": {"_id": ObjectId(id), "STATUS_": "%s" % status,
                                              "LOCKTIME_": "%s" % str(time.time())}})


class MeiPian_Content_Start(C_Templet_Spdiers):

    def start_requests(self):
        # 去mongo中取状态为1的数据，只取一条数据
        try:
            self.log.info('从mongo地址中取一条数据')
            # STATUS是为了保证数据在抓取时，调度不会调到同一个url：
            # 1为未获取内容状态，2正在获取，获取完成后整条删除
            # 从spider_temp_url中获取一条数据，STATUS为1的数据
            url_result = self.temp_mongodb.S_Mongodb_One(where={'STATUS_': '1'})
        except Exception as e:
            self.log.error(e)
            print(4)
            return False
        # 取状态为2的数据
        if not url_result:
            # 5分钟后可以再次获取这条数据进行爬取
            match = {"$where": "function(){return %d-this.LOCKTIME_>300}" % time.time()}
            try:
                url_result = self.temp_mongodb.S_Mongodb_One(match=match)
            except Exception as e:
                print(4)
                self.log.error(e)
                return False
            if not url_result:
                self.log.error('去mongodb中取一条数据，但没有找到可用数据，终止程序')
                print(0)
                return False
        _id = url_result['_id']
        # 更新status的状态
        self.u_data(_id, '2')

        if not isinstance(url_result, list):
            url_result = [url_result]

        for urll in url_result:
            compare = []
            result = []
            grad_result = []
            self.url = urll['URL_']
            try:
                self.param = urll['PARAM_']
            except KeyError:
                self.param = []
            for code_ in self.code_:
                r, c = self.__request_middware(code_, self.url)
                r['URL_'] = self.url
                result.append(r)
                compare.append(c)
            # 取匹配度最大的数据
            if len(compare) > 1:
                self.log.info('找出匹配度最高的数据')
                index = compare.index(max(compare))
                final_list = result[index]
                result = []
                result.append(final_list)
            if len(grad_result) > 1:
                self.log.error('抓包多个内容模板是否要做匹配度检查请检查')
                print(1)
                return None
            elif len(grad_result) == 1 and len(result) == 0:
                result = grad_result
            elif len(grad_result) == 1 and len(result) == 1:
                result[0] = grad_result[0].update(result[0])
            elif len(grad_result) == 0:
                pass
            else:
                self.log.error('内容抓取数据失败')
                print(1)
                return None
            if result:
                try:
                    # 存储内容
                    self.data_mongodb.I_Mongodb(result)
                    del result[0]['CONTENT_']
                    # 存储主键
                    self.op_key.I_Mongodb(result)
                    self.temp_mongodb.R_Mongodb({'_id': ObjectId(_id)})
                    self.log.info('内容抓取数据成功，并成功插入mongo中')
                    print(0)
                except Exception as e:
                    self.log.error('数据插入mongo失败，程序终止')
                    self.log.error(e)
                    print(4)
            else:
                self.log.info('插入mongo数据为空,result为空，未匹配到数据或者其它问题，程序终止')
                print(4)

    def __all_parm(self, middware, code_):
        self.log.info('开始ALL模式')

        # 全局变量处理
        global_parm = {}
        gl = middware['global_parm']
        if gl:
            self.log.info('替换全局变量')
            for m_ in gl:
                for pa_ in self.param:
                    name = m_['value'].replace(code_ + '.', '')
                    if pa_['code'] == name:
                        global_parm[m_['code']] = pa_['value']
        global_parm['ENTITY_NAME_'] = self.entity_name
        global_parm['ENTITY_CODE_'] = self.entity_code
        global_parm['URL_'] = self.url
        global_parm['DEALTIME_'] = str(time.time())
        global_parm['DATETIME_'] = get_date_time()
        return global_parm

    def __get_global_parm(self, midd, code_):
        # 全局变量处理
        global_parm = {}
        gl = midd[0]['global_parm']
        out_put = get_jp_value(midd[0], '$.out_put[*].code')
        if len(gl) > 0:
            self.log.info('替换全局变量')
            for m_ in gl:
                for pa_ in self.param:
                    name = m_['value'].replace(code_ + '.', '')
                    if pa_['code'] == name and pa_['code'] in out_put:
                        global_parm[m_['code']] = pa_['value']
        return global_parm

    def __get_middware(self, code_):
        """
        获取内容中间件信息配置
        :param code_:
        :return:
        """
        try:
            Middware = Content_Middleware(code_, parm=self.param).Invoking_Diff()
            if not Middware:
                print(1)
                self.log.error('内容中间件执行失败，程序终止')
                raise Exception('False')
        except:
            print(1)
            self.log.error('内容中间件执行异常，程序终止')
            raise Exception('False')
        self.log.info('内容模板中间件执行成功')
        self.log = ICrawlerLog('spider').save
        return Middware

    def __request_middware(self, code_, url):
        # 调用中间件解析数据
        Middware = self.__get_middware(code_)
        gr = {}
        rs = {}
        co = 0
        child_url = []
        for midd in Middware:
            midd_config = midd['config']
            # 处理全是全局参数的情况
            if 'type1' in midd_config and midd_config['type1'] == 'ALL':
                # result.append(self.__all_parm(midd_config,code_))
                return self.__all_parm(midd_config, code_), 0
            # 内容page模式处理
            if midd_config['CONTENT']:
                a_all = self.op_key.S_Mongodb(collection=str(self.dbname) + '_KEY_', output='URL_')
                if url in a_all:
                    return False
                content_data = self.get_meipian_content(url=url)
                if not content_data:
                    return False
                # 处理地址映射参数到内容
                tcdict = self.__get_global_parm(midd_config['CONTENT'], code_)
                tcdict.update(content_data)
                rs.update(tcdict)
            rs.update(gr)

            if midd['child']:
                if not child_url:
                    raise Exception('child_url为空')
                for child, c_url in list(zip(midd['child'], child_url)):
                    child_rs, child_co = self.__request_middware(child, c_url)
                    rs.update(child_rs)
                    co = child_co + co
            return rs, co

    def proxies(self):
        """
        获取ip代理
        :return:
        """
        try:
            ip = RedisClient().get()
        except Exception as e:
            self.log.error(e)
            print(6)
            return False
        proxies = {
            "http": 'http://' + ip,
            "https": 'https://' + ip,
        }
        return proxies

    def get_meipian_content(self, url):
        content_data = dict()
        img_dir = FileConfigParser().get_path(server=platform_system(), key='wechatimg')
        img_dir = root_path + img_dir
        # 内容请求
        try:
            content = requests.request(method='GET',
                                       url=url,
                                       proxies=self.proxies(),
                                       verify=False,
                                       headers={'User-Agent': random.choice(user_agent_list)}).text
        except Exception as e:
            self.log.error(e.args)
            self.log.error('美篇地址内容错误！')
            return False

        from scrapy.selector import Selector
        # 处理图片替换
        # print(content)
        data = Selector(text=content)
        # 处理css
        for css in data.xpath('head/link'):
            link = css.xpath('@href').extract_first()
            if link and 'css' in link:
                # if isinstance(i.extract(),str):
                #     content = content.replace(link,'')
                if link[:2] == '//':
                    # link = 'https:' + link
                    content = content.replace(link, 'https:' + link)

                # css = requests.get(url = link,headers=header).text
                # content = content + '\n <style>' + css + '</style>'

        # 处理图片替换
        for img in data.xpath('//img'):

            showimg = img.xpath('@show-img').extract_first()
            if showimg:
                old = 'show-img="%s"' % showimg
                content = content.replace(old, '')

            src = img.xpath('@src').extract_first()
            if src:
                img_name = src.split('/')[-1].replace('jpg-mobile', 'png')
                # 下载图片
                time.sleep(1)
                Download(src, img_dir, img_name)
                # 图片base64编码
                img_base64 = get_base64(img_dir, img_name)
                os.remove(img_dir + img_name)
                old = 'src="%s"' % src
                new = 'src="data:image/png;base64,%s"' % (img_base64)
                # 重新组装的内容，图片转为base64编码
                content = content.replace(old, new)
        # print(content)
        # 处理背景图片
        background_images = re.findall('background-image: url\((https.*?g)\)', content)
        for bgdimg in background_images:
            # print(bgdimg)
            bgdimg_name = bgdimg.split('/')[-1]
            # 下载图片
            time.sleep(1)
            Download(bgdimg, img_dir, bgdimg_name)
            # 图片base64编码
            bgdimg_base64 = get_base64(img_dir, bgdimg_name)
            os.remove(img_dir + bgdimg_name)
            bgd_old = bgdimg
            bgd_new = "'data:image/png;base64,{}'".format(str(bgdimg_base64))
            content = content.replace(bgd_old, bgd_new)
        # print(content)
        # results = re.sub(re.compile(r'<img show-img(.*?)jpg"'), '<img ', content)
        dealtime = time.time()
        datatime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(dealtime))
        # 存储数据项
        content_data['SOURCE_'] = '美篇'
        content_data['ENTITY_NAME_'] = self.entity_name
        content_data['ENTITY_CODE_'] = self.entity_code
        content_data['CONTENT_TYPE_'] = 'html'
        content_data['CONTENT_'] = content
        content_data['DEALTIME_'] = dealtime
        content_data['DATETIME_'] = datatime
        return content_data
