import json
import re

import requests
import time
import random
import jsonpath
from bson.objectid import ObjectId

from OperateDB.OpRedis import RedisClient
from SpidersLog.ICrwlerLog import ICrawlerLog
from IPProxy.IPProxy import IPProxy
from OperateDB.OpMongodb import Op_MongoDB
from TemplateMiddleware.ContentMidlewares import Content_Middleware
from OperateDB import OPMysql


class WeiBoSpider:

    name = 'weibo'

    def __init__(self, url, entity_code, entity_name, *args, **kwargs):
        """
        定义参数
        :param code_: code
        :param url_: 入口url
        :param args:
        :param kwargs:
        """
        super(WeiBoSpider, self).__init__(*args, **kwargs)
        self.code_ = entity_code
        self.url = url
        self.entity_name = entity_name

        self.basic_info_mongodb = Op_MongoDB(db='spider_data', coll='WEIBOBASICINFO', key='null')
        self.info_mongodb = Op_MongoDB(db='spider_data', coll='WEIBOINFO', key='null')

        self.comments_url = 'https://m.weibo.cn/comments/hotflow'
        self.content_url = 'https://m.weibo.cn/statuses/extend'
        self.main_url = 'https://m.weibo.cn/api/container/getIndex'
        self.company_url = 'https://m.weibo.cn/u/'

        self.log = ICrawlerLog('spider').save

    def ip_proxy(self):
        log = ICrawlerLog(name='spider').save
        try:
            # 目前正使用的ip代理
            # ip = IPWeChat().g_ip()
            # 快代理;
            # ip = FastProxy().get_ip()
            # redis代理池
            ip = RedisClient().get()
            log.info('当前使用ip为%s' % ip)
            proxies = {
                       'http': 'http://' + ip,
                       'https': 'https://' + ip
                       }
            return proxies
        except Exception as e:
            log.error(e.args)
            print(6)
            return False

    def query_code(self):
        """
        通过微博账号来查询数据
        :param code: 微博账号
        :return:
        """

        mid_data = ['WeiBo.CONTENT', 'WeiBo.CONTENT1']
        try:
            middle_main = Content_Middleware(mid_data[0]).Invoking_Diff()
        except:
            middle_main = None
        if middle_main:
            self.log.info('地址中间件程序执行成功')
            main_urls = middle_main[0].get('url')
            if main_urls :
                main_url = main_urls[0]
            else:
                main_url = self.main_url
        else:
            self.log.error('地址中间件执行异常')
            main_url = self.main_url

        weibo_code = self.url.split('?')[0].split('/')[-1]
        # weibo_code = '5641866032'
        param_top = {
            'type': 'uid',
            'value': str(weibo_code),
        }

        # 微博基本资料信息
        microblog_basic_infor = dict()

        # 主页/微博/照片的containerids
        containerids = dict()
        time.sleep(random.uniform(1, 3))
        try:
            res_m = requests.get(url=main_url, params=param_top, proxies=self.ip_proxy(), timeout=20, allow_redirects=False)
        except Exception as e:
            print(e.args)
            self.log.error('微博首页请求失败！')
            return False
        microblog_basic_infor['MAIN_URL_'] = 'https://m.weibo.cn/u/' + weibo_code
        res_main = res_m.json()
        if res_main.get('ok') == 1:
            try:
                microblog_basic_infor['WEIBO_CODE_'] = str(weibo_code)
                microblog_basic_infor['NAME_'] = jsonpath.jsonpath(res_main, 'data.userInfo.screen_name')[0]
                microblog_basic_infor['FOCUS_'] = jsonpath.jsonpath(res_main, 'data.userInfo.follow_count')[0]
                microblog_basic_infor['FANS_'] = jsonpath.jsonpath(res_main, 'data.userInfo.followers_count')[0]
                containerids['home_page_containerid'] = jsonpath.jsonpath(res_main, 'data.tabsInfo.tabs[0].containerid')[0]
                containerids['microblog_containerid'] = jsonpath.jsonpath(res_main, 'data.tabsInfo.tabs[1].containerid')[0]
                containerids['image_containerid'] = jsonpath.jsonpath(res_main, 'data.tabsInfo.tabs[2].containerid')[0]
            except Exception as e:
                self.log.error('内容匹配错误')
                return False

            # 所属公司请求数据
            param_company = {
                'containerid': containerids['home_page_containerid']
            }
            try:
                time.sleep(random.randint(1, 3))
                res_c = requests.get(url=main_url, params=param_company, proxies=self.ip_proxy(), timeout=20, allow_redirects=False)
                microblog_basic_infor['COMPANY_URL_'] = res_c.url
                res_company = res_c.json()
            except:
                res_company = None
                self.log.error('微博公司网页请求错误！')
            try:
                microblog_basic_infor['COMPANY_'] = jsonpath.jsonpath(res_company, 'data.cards.0..card_group.1.item_content')[0]
            except Exception as e:
                self.log.error('内容匹配错误')
            # 详细资料请求数据
            param_basic_information = {
                'containerid': '{}_-_INFO'.format(containerids.get('home_page_containerid')),
            }
            try:
                res_m_b_i = requests.get(url=main_url, params=param_basic_information, proxies=self.ip_proxy(), timeout=20, allow_redirects=False)
            except:
                self.log.error('内容匹配错误')
                return False
            microblog_basic_infor['DETAILED_URL_'] = res_m_b_i.url
            res_microblog_basic_information = res_m_b_i.json()
            if res_microblog_basic_information:
                try:
                    microblog_basic_infor['VIRIFIED_'] = jsonpath.jsonpath(res_microblog_basic_information, 'data.cards[0].card_group[2].item_content')[0]
                    microblog_basic_infor['BIREF_'] = jsonpath.jsonpath(res_microblog_basic_information, 'data.cards[0].card_group[3].item_content')[0]
                    microblog_basic_infor['LOCATION_'] = jsonpath.jsonpath(res_microblog_basic_information, 'data.cards[1].card_group[1].item_content')[0]
                except Exception as e:
                    self.log.error('内容匹配错误')
                    return False

            # 保存基本资料信息
            microblog_basic_infor['ENTITY_NAME_'] = self.entity_name
            microblog_basic_infor['BANK_CODE_'] = self.code_
            microblog_basic_infor['DEALTIME_'] = time.time()
            # 定位元素传入参数(字典)
            main_position_ele = dict()
            main_position_ele['WEIBO_CODE_'] = str(weibo_code)
            self.updata_info(self.basic_info_mongodb, main_position_ele, microblog_basic_infor)
            self.log.info('{}新浪微博基本资料存储完成!'.format(microblog_basic_infor.get('NAME_')))
            # print('{}新浪微博基本资料存储完成!'.format(microblog_basic_infor.get('NAME_')))

            # 微博信息
            page_content = 1  # 第一页

            while True:
                param_microblog = {
                    'containerid': '{}'.format(containerids.get('microblog_containerid')),
                    'page': str(page_content)
                }
                try:
                    time.sleep(random.randint(1, 3))
                    res_mic = requests.get(url=main_url, params=param_microblog, proxies=self.ip_proxy(), timeout=20, allow_redirects=False)
                except Exception as e:
                    self.log.error('第一页请求错误！')
                    return False
                res_microblog = res_mic.json()
                # 每一页最多有20条数据
                for count_content in range(21):
                    # 第一条
                    count_content += 1
                    contents = []
                    content_info = dict()
                    try:
                        try:
                            # 转发
                            content_info['RELAYS_'] = \
                            jsonpath.jsonpath(res_microblog, 'data.cards.{}.mblog.reposts_count'.format(count_content))[0]
                            # 点赞
                            content_info['PRAISES_'] = \
                            jsonpath.jsonpath(res_microblog, 'data.cards.{}.mblog.attitudes_count'.format(count_content))[0]
                            # 评论
                            content_info['REPLIES_'] = \
                            jsonpath.jsonpath(res_microblog, 'data.cards.{}.mblog.comments_count'.format(count_content))[0]
                        except:
                            continue
                        content_img_num = 0
                        content_img_list = []
                        while True:
                            try:
                                content_img = jsonpath.jsonpath(res_microblog, 'data.cards.{}.mblog.pics.{}.url'.format(count_content, content_img_num))
                                content_img_list += content_img
                            except Exception as e:
                                self.log.error(e)
                                break
                            content_img_num += 1
                        # print(content_img_list)
                        content_info['CONTENT_IMAGES_'] = content_img_list

                        # 发布时间
                        u_time_= \
                            jsonpath.jsonpath(res_microblog, 'data.cards.{}.mblog.created_at'.format(count_content))[0]
                        content_info['PUBLISH_TIME_'] = self.format_time(str(u_time_))
                        # 评论/留言comments_id
                        comments_id = \
                            jsonpath.jsonpath(res_microblog, 'data.cards.{}..mblog.id'.format(count_content))[0]
                        try:
                            time.sleep(random.randint(1, 3))
                            res_content = requests.get(url=self.content_url + '?id=' + comments_id, proxies=self.ip_proxy(), timeout=20, allow_redirects=False).json()
                        except Exception as e:
                            self.log.error(e)
                            # 内容请求失败，继续下一条信息！
                            continue
                        try:
                            text_content = \
                                jsonpath.jsonpath(res_content, 'data.longTextContent')[0]
                            from scrapy.selector import Selector
                            content_info['CONTENT_'] = ''.join(Selector(text=text_content).xpath('//text()').extract())
                        except Exception as e:
                            self.log.error(e)
                            # 没有内容，继续下一条信息！
                            continue
                        content_info['CONTENT_CODE_'] = comments_id
                        content_info['CONTENT_URL_'] = 'https://m.weibo.cn/detail/' + comments_id

                        # 处理评论信息
                        comments_results = []
                        comments_results, max_id = self.comments_data(comments_results, comments_id)
                        if not comments_results and comments_results != []:
                            return False
                        # 反复回调,拿到所有的评论信息
                        while max_id:
                            comments_results, max_id = self.comments_data(comments_results, comments_id, max_id)
                        print(comments_results)
                        content_info['INFO_COMMENTS_'] = comments_results
                        # 将评论信息汇总到该文章下
                        contents.append(content_info)
                        # 数据存储
                        for i in contents:
                            i['ENTITY_NAME_'] = self.entity_name
                            i['BANK_CODE_'] = self.code_
                            i['DEALTIME_'] = time.time()
                            # 内容定位元素
                            content_position_ele = dict()
                            content_position_ele['CONTENT_CODE_'] = i.get('CONTENT_CODE_')
                            self.updata_info(self.info_mongodb, content_position_ele, i)
                        # self.log.info('第{}条新浪微博内容存储完成!'.format(count_content+1))
                        # print('{}条微博存储完成'.format(count_content+1))
                        if content_info:
                            continue
                    except Exception as e:
                        self.log.error(e)
                        break
                # self.log.info('第{}页微博状态内容存储完成!'.format(page_content))
                # print('第{}页微博状态内容存储完成!'.format(page_content))
                try:
                    page_content = jsonpath.jsonpath(res_microblog, 'data.cardlistInfo.page')[0]
                except Exception as e:
                    self.log.error(e)
                    break
                    # page_content = None
                if page_content is None or page_content == 101:
                    break
                else:
                    continue
            self.log.info('{}爬取成功！'.format(self.entity_name))
            return True
        else:
            self.log.error('{}的账号不存在或者异常,数据无法抓取!'.format(self.entity_name))
            return False
            #print('{}的账号不存在或者异常,数据无法抓取!'.format(self.entity_name))

    def comments_data(self, comments_results, comments_id, max_i=0):
        """
        处理当页评论/留言信息（一页有10~20条评论信息）
        :param comments_dict: 内容数据
        :param comments_id: 内容状态id
        :param max_id: 页码(为0时为最后一页,页码是'138830612324215'字段)
        :return:
        """

        # 评论信息/留言信息
        # param_comments = {
        #     'mid': comments_id,
        #     'max_id': max_i,
        # }
        try:
            time.sleep(random.randint(1, 3))
            proxies = self.ip_proxy()
            cookies = json.loads(RedisClient(name='weibo_cookies').get())
            # print(cookies)
            first_res = requests.get(url='https://m.weibo.cn/comments/hotflow?id={0}&mid={0}&max_id_type=0'.format(comments_id), cookies=cookies, proxies=proxies, timeout=20, allow_redirects=False)
            res_com = requests.get(url='https://m.weibo.cn/comments/hotflow?id={0}&mid={0}&max_id={1}&max_id_type=0'.format(comments_id, max_i), cookies=cookies, proxies=proxies, timeout=20, allow_redirects=False)
            # print(res_com.text)
            # res_com = requests.get(url=self.comments_url, params=param_comments, proxies=self.ip_proxy(), timeout=10, allow_redirects=False)
            if res_com.status_code == 200:
                res_com = res_com.json()
        except Exception as e:
            self.log.error(e)
            return comments_results, 0

        # 分页id
        try:
            if res_com['ok'] == 1:
                max_i = jsonpath.jsonpath(res_com, 'data.max_id')[0]
            else:
                return comments_results, 0
        except Exception as e:
            self.log.error(e)
            # max_id赋值为0,停止请求
            max_i = 0
        count_comments = 0

        while True:
            comments_dict = dict()
            try:
                comm_text = \
                    jsonpath.jsonpath(res_com, 'data.data.{}.text'.format(count_comments))[0]
                from scrapy.selector import Selector
                comments_dict['COMMENT_'] = ''.join(Selector(text=comm_text).xpath('//text()').extract())

                REPLIER_TIME_ = \
                    jsonpath.jsonpath(res_com, 'data.data.{}.created_at'.format(count_comments))[0]
                comments_dict['REPLIER_TIME_'] = self.cst_to_str(str(REPLIER_TIME_))
                comments_dict['REPLIER_HEAD_'] = \
                    jsonpath.jsonpath(res_com, 'data.data.{}.user.avatar_hd'.format(count_comments))[0]

                comments_dict['REPLIER_PRAISES_'] = \
                    jsonpath.jsonpath(res_com, 'data.data.{}.like_count'.format(count_comments))[0]

                comments_dict['REPLIER_'] = \
                    jsonpath.jsonpath(res_com, 'data.data.{}.user.screen_name'.format(count_comments))[0]

                comments_dict['REPLIER_REPLIES_'] = \
                    jsonpath.jsonpath(res_com, 'data.data.{}.total_number'.format(count_comments))[0]

                if comments_dict:
                    comments_results.append(comments_dict)
                    count_comments += 1
            except Exception as e:
                self.log.error(e)
                break
        return comments_results, max_i

    def updata_info(self, mongod, elem_dict, item):
        """
         数据去重保存
        :param mongod:  collections
        :param elem_dict: 定位元素(字典)
        :param item: 需要存储的数据(json格式)
        :return:
        """
        try:
            mongod.conn_db_coll().update(elem_dict, {"$set": item}, True)
        except Exception as e:
            self.log.error(e)
            self.log.error('mongodb数据库数据存储异常!')
        finally:
            mongod.close_mongo()

    def save_data(self, mongod, results):
        """
        :param results: 微博基本资料和微博内容及评论
        :return:
        """
        try:
            mongod.I_Mongodb(results)
        except Exception as e:
            self.log.error(e)
            self.log.error('mongodb数据库数据存储异常!')

    def format_time(self,d_time):
        """
        格式化发布时间
        :param d_time:
        :return:
        """
        try:
            if re.match('\d+?-\d+?', d_time) and len(d_time) <= 5:
                data_time = time.strftime('%Y-', time.localtime()) + d_time
            elif re.match('^\d+?-\d+?-\d+?', d_time) and 8 <= len(d_time) <= 10:
                data_time = d_time
            else:
                data_time = time.strftime('%Y-%m-%d', time.localtime(time.time()))
        except Exception as e:
            self.log.error(e)
            data_time = d_time
        return data_time

    def cst_to_str(self, cstTime):
        """
        格式化评论时间
        :param cstTime:
        :return:
        """
        try:
            tempTime = time.strptime(cstTime, '%a %b %d %H:%M:%S +0800 %Y')
            resTime = time.strftime('%Y-%m-%d %H:%M:%S', tempTime)
            return resTime
        except:
            return cstTime





