# encoding: utf-8
from OperateDB.OpMongodb import Op_MongoDB
from OperateDB.OpRedis import RedisClient
from SpidersLog.ICrwlerLog import ICrawlerLog
from TemplateMiddleware.ContentMidlewares import Content_Middleware
from bson.objectid import ObjectId
from Exception.HttpCode import HttpCode
from Env.ParseYaml import DBConfigParser
from ICrawlerSpiders.useragent import user_agent_list
from ICrawlerSpiders.DataParse.GrabParse import Grad_Parse
from ICrawlerSpiders.DataParse.PageParse import Page_Parse
from SpiderTools.Tool import get_date_time
from SpiderTools.Tool import get_jp_value
from IPProxy.IPProxy import IPProxy
from SpiderTools.DealPdf import PDF
from SpiderTools.Tool import get_dict
from staticparm import pdf_dir
from SpiderTools.Tool import get_base64
import random
import ssl
import time
import requests

# path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))

# root_path = os.path.normpath(os.path.join(path, os.pardir))

ssl._create_default_https_context = ssl._create_unverified_context

# 这句是不让它报这个警告错误
# [py.warnings] WARNING: D:\Python35\lib\site-packages\urllib3\connectionpool.py:858:
# InsecureRequestWarning: Unverified HTTPS request is being made.
# Adding certificate verification is strongly advised.
# See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
requests.packages.urllib3.disable_warnings()

class C_Templet_Spdiers:

    #name ='ContentTempletSpider'

    def __init__(self, code_, type_, entity_code, entity_name,dbname,method,key,*args, **kwargs):
        super(C_Templet_Spdiers, self).__init__(*args, **kwargs)
        self.code_ = code_
        self.type_ = type_
        self.entity_code = entity_code
        self.entity_name = entity_name
        self.dbname = dbname
        self.method = method
        self.status = ''

        #self.parm = list(zip(code_.split(','), type_.split(',')))
        self.code_ = code_.split(',')
        if isinstance(self.code_,str):
            self.code_ = [self.code_]

        config = DBConfigParser()
        temp_db = config.get_temp_db()
        self.data_db = config.get_data_db()

        self.data_mongodb = Op_MongoDB(db=self.data_db, coll=dbname,key='null')
        self.temp_mongodb = Op_MongoDB(db=temp_db, coll=entity_code,key='null')

        self.log = ICrawlerLog('spider').save

    def u_data(self,id,status):
        '''更改数据状态
        :param id: 数据id
        :param status: 状态值
        :return:
        '''
        st = False
        if self.status == 2:
            match = {"$where": "function(){return %d-this.LOCKTIME_>300}" % time.time()}
            try:
                st = self.temp_mongodb.S_Mongodb_One(match=match)
                self.status = 2
            except Exception as e:
                print(4)
                self.log.error(e)
                return False
        if (self.status == 1 and st == False) or (self.status == 2 and st):
            result = self.temp_mongodb.U_Mongodb({"_id": ObjectId(id),"STATUS_":"%s" %self.status},
                          {"$set": {"_id": ObjectId(id), "STATUS_": "%s" %status, "LOCKTIME_": "%s" % str(time.time())}})

            if result['updatedExisting']:
                return True

        return False


class Content_Start(C_Templet_Spdiers):

    def start_requests(self):

        #去mongo中取状态为1的数据，只取一条数据
        try:
            self.log.info('从mongo地址中取一条数据')
            url_result = self.temp_mongodb.S_Mongodb_One(where={'STATUS_': '1'})
            self.status = 1
        except Exception as e:
            self.log.error(e)
            print(4)
            return False

        #取状态为2的数据
        if not url_result:
            match = {"$where": "function(){return %d-this.LOCKTIME_>300}" % time.time()}
            try:
                url_result = self.temp_mongodb.S_Mongodb_One(match=match)
                self.status = 2
            except Exception as e:
                print(4)
                self.log.error(e)
                return False
            if not url_result:
                self.log.error('去mongodb中取一条数据，但没有找到可用数据，终止程序')
                print(0)
                return False

        _id = url_result['_id']

        if not self.u_data(_id, '2'):
            print(4)
            return False

        try:
            self.ip = RedisClient().get()
        except Exception as e:
            self.log.error(e)
            print(6)
            return False

        self.proxies = {
            "http": 'http://' + self.ip,
            "https": 'https://' + self.ip,
        }

        if not isinstance(url_result,list):
            url_result = [url_result]

        for urll in url_result:
            compare = []
            result = []
            grad_result = []

            self.url = urll['URL_']

            try:
                self.param = urll['PARAM_']
            except KeyError:
                self.param = []

            for code_ in self.code_:
                r,c = self.__request_middware(code_,self.url)
                r['URL_'] = self.url
                result.append(r)
                #grad_result.append(g)
                compare.append(c)

            #取匹配度最大的数据
            if len(compare) > 1:
                self.log.info('找出匹配度最高的数据')
                index = compare.index(max(compare))
                final_list = result[index]
                result = []
                result.append(final_list)

            if len(grad_result) > 1:
                self.log.error('抓包多个内容模板是否要做匹配度检查请检查')
                print(1)
                return None
            elif len(grad_result) == 1 and len(result) == 0:
                result = grad_result
            elif len(grad_result) == 1 and len(result) == 1:
                result[0] = grad_result[0].update(result[0])
            elif len(grad_result) == 0:
                pass
            else:
                self.log.error('内容抓取数据失败')
                print(1)
                return None

            if result:
                try:
                    self.data_mongodb.I_Mongodb(result)
                    # self.tempmongodb.U_Mongodb({"url": "%s" % response.url,"status": "1"}, {'$set': {"status": "2"}})
                    self.temp_mongodb.R_Mongodb({'_id': ObjectId(_id)})
                    self.log.info('内容抓取数据成功，并成功插入mongo中')
                    print(0)
                except Exception as e:
                    self.log.error('数据插入mongo失败，程序终止')
                    self.log.error(e)
                    print(4)
            else:
                self.log.info('插入mongo数据为空,result为空，未匹配到数据或者其它问题，程序终止')
                print(4)

    def __grab_requests(self,middware):

        self.log.info('开始抓包模式')

        #Middware = self.___get_middware(code_, param, None)

        _result = []

        for midd in middware:
            pheaders = midd['header']
            pform = midd['parm']
            if isinstance(pform, str):
                pform = eval(pform)
            if isinstance(pform, list) and len(pform) > 0:
                pform = pform[0]
            #refmongoval = midd['mongodb'][3]
            pmethod = midd['method']
            purl = midd['url'][0]
            final_out = midd['final_out']
            out_put = midd['out_put']
            con_out = midd['content_out']
            exprconfig = midd['expr']
            global_parm = midd['global_parm']
            text_type = midd['textType']
            content_algo = midd['content_algo']


            if pmethod == 'GET':
                parm = pform
                formdata = None
            if pmethod == 'POST':
                formdata = pform
                parm = None

            # 不加verify=False，会报requests.exceptions.SSLError: HTTPSConnectionPool 错误
            self.log.info('开始请求%s，请求参数为%s,头信息为%s,请求代理为%s' % (purl, pform, pheaders,self.proxies))

            content_data = requests.request(method=pmethod, url=purl, params=parm, data=formdata,
                                            headers=pheaders,proxies=self.proxies, verify=False,allow_redirects=False)

            if content_data.status_code in [200, 304]:

                encode = content_data.encoding

                if not encode:
                    encode = 'UTF-8'

                if encode == 'ISO-8859-1':
                    encodings = requests.utils.get_encodings_from_content(content_data.text)
                    if encodings:
                        encode = encodings[0]
                    else:
                        encode = content_data.apparent_encoding

                content_data = content_data.content.decode(encode, 'replace')

                if len(content_data) > 0:
                    self.log.info('请求%s成功' % purl)
                    self.log.info('开始处理抓包模式的数据')
                    gresult = Grad_Parse().grad_content_parse(content_data, meta={"url": purl,
                                                                                  "final_out": final_out,
                                                                                  "out_put": out_put,
                                                                                  "con_out": con_out,
                                                                                  "entity_name": self.entity_name,
                                                                                  "entity_code": self.entity_code,
                                                                                  'exprconfig': exprconfig,
                                                                                  'textType':text_type,
                                                                                  'content_algo':content_algo
                                                                                  })
                    if not gresult:
                        self.log.error('内容抓包数据匹配失败，程序终止，网址:%s' % purl)
                        print(1)
                        raise Exception('False')

                    if isinstance(gresult, dict):
                        _result.append(gresult)
                else:
                    self.log.error('请求%s返回数据为空' % purl)
                    print(1)
                    raise Exception('False')
            else:
                self.log.error('抓包%s失败' % purl)
                self.log.error(HttpCode().get_code_info(content_data.status_code))
                # IPProxy().del_ip(self.ip)
                print(2)
                raise Exception('False')

        grad = {}
        if len(_result) > 0:
            for i_ in _result:
                grad.update(i_)
            grad['url'] = purl
            grad['dealtime'] = str(time.time())

        return grad

    def __page_requests(self,middware,code_,url,child_xpath,child_prefix):

        self.log.info('开始页面模式')

        try:
            self.log.info('开始请求%s,请求代理为%s' % (self.url,self.proxies))
            content = requests.request(method='GET', url=url, proxies=self.proxies,verify=False,
                                       headers={'User-Agent': random.choice(user_agent_list)}
                                       #,allow_redirects=False
                                       )
        except requests.exceptions.ConnectionError:
            self.log.error('ConnectionError,请求%s失败' % self.url)
            print(2)
            raise Exception('False')

        if content.status_code in [200, 304, 301]:

            encode = content.encoding

            if not encode:
                encode = 'UTF-8'

            if encode == 'ISO-8859-1':
                encodings = requests.utils.get_encodings_from_content(content.text)
                if encodings:
                    encode = encodings[0]
                else:
                    encode = content.apparent_encoding

            content = content.content.decode(encode,'replace')

            self.log.info('开始处理页面模式的数据')
            temp_compare,child_url = Page_Parse().page_content_parse(content, meta={'pattern': middware, 'url': url,
                                                                          "entity_name": self.entity_name,
                                                                          "entity_code": self.entity_code,
                                                                          "content_code": code_,
                                                                          "algo":middware[0]['algo'],
                                                                          "child_xpath":child_xpath,
                                                                          "child_prefix":child_prefix
                                                                          })
            if not temp_compare:
                self.log.error('内容page模式数据匹配失败，网址:%s' %url)
                print(1)
                raise Exception('False')

            return temp_compare,child_url
        else:
            self.log.error('page模式访问网页%s失败' %url)
            self.log.error(HttpCode().get_code_info(content.status_code))
            # IPProxy().del_ip(self.ip)
            print(2)
            # self.temp_mongodb.R_Mongodb({'_id': ObjectId(_id)})
            raise Exception('False')

    def __all_parm(self,middware,code_):
        self.log.info('开始ALL模式')

        # 全局变量处理
        global_parm = {}
        gl = middware['global_parm']
        if gl:
            self.log.info('替换全局变量')
            for m_ in gl:
                for pa_ in self.param:
                    name = m_['value'].replace(code_ + '.', '')
                    if pa_['code'] == name:
                        global_parm[m_['code']] = pa_['value']
        global_parm['ENTITY_NAME_'] = self.entity_name
        global_parm['ENTITY_CODE_'] = self.entity_code
        global_parm['URL_'] = self.url
        global_parm['DEALTIME_'] = str(time.time())
        global_parm['DATETIME_'] = get_date_time()
        return global_parm

    def __get_file(self,midd,url,code_):
        pdf = PDF()
        file = {}
        content = ''

        global_parm = self.__get_global_parm(midd,code_)
        file.update(global_parm)

        for FILE in midd:
            name = self.entity_code + '_' + url.split('/')[-1]
            code = FILE['code'].replace(code_ + '.', '')
            if FILE['datatype'] == 'IMGPDF' or FILE['datatype'] == 'NOIMGPDF':
                try:
                    pdf.download_pdf(url, pdf_dir, name)
                except Exception as e:
                    self.log.error('类型1为附件，在线PDF下载失败,url:' % url)
                    raise Exception(e)

            if FILE['datatype'] == 'IMGPDF':
                content = pdf.imgpdf_change_img_local(pdf_dir + name)
                file[code] = content
                file['PDF_BASE64_'] = get_base64(pdf_dir,name)
            if FILE['datatype'] == 'NOIMGPDF':
                content = pdf.noimgpdf_change_word(pdf_dir + name)
                file[code] = content
                file['PDF_BASE64_'] = get_base64(pdf_dir,name)
            if content and FILE['expr']:
                tempdict = get_dict(FILE['expr'][code], content)
                file.update(tempdict)
            file['ENTITY_NAME_'] = self.entity_name
            file['ENTITY_CODE_'] = self.entity_code
            file['URL_'] = url
            file['DEALTIME_'] = str(time.time())
            file['DATETIME_'] = get_date_time()
        return file

    def __get_global_parm(self,midd,code_):
        # 全局变量处理
        global_parm = {}
        gl = midd[0]['global_parm']
        out_put = get_jp_value(midd[0],'$.out_put[*].code')
        if len(gl) > 0:
            self.log.info('替换全局变量')
            for m_ in gl:
                for pa_ in self.param:
                    name = m_['value'].replace(code_ + '.', '')
                    if pa_['code'] == name and pa_['code'] in out_put:
                        global_parm[m_['code']] = pa_['value']
        return global_parm

    def __get_middware(self,code_):
        try:
            Middware = Content_Middleware(code_, parm=self.param).Invoking_Diff()
            if not Middware:
                print(1)
                self.log.error('内容中间件执行失败，程序终止')
                raise Exception('False')
        except:
            print(1)
            self.log.error('内容中间件执行异常，程序终止')
            raise Exception('False')

        self.log.info('内容模板中间件执行成功')

        self.log = ICrawlerLog('spider').save

        return Middware

    def __request_middware(self,code_,url):
        Middware = self.__get_middware(code_)
        gr = {}
        rs = {}
        co = 0
        child_url = []

        for midd in Middware:

            midd_config = midd['config']

            # 处理全是全局参数的情况
            if 'type1' in midd_config and midd_config['type1'] == 'ALL':
                # result.append(self.__all_parm(midd_config,code_))
                return self.__all_parm(midd_config, code_) ,0

            # 内容抓包模式处理
            if midd_config['GRAB']:
                gr.update(self.__grab_requests(midd_config['GRAB']))
                global_parm = self.__get_global_parm(midd_config['GRAB'],code_)
                gr.update(global_parm)
                if not gr:
                    return False
                #grad_result.append(gr)

            # 内容page模式处理
            if midd_config['CONTENT']:
                temp_compare,child_url = self.__page_requests(midd_config['CONTENT'],code_,url,midd['child_xpath']
                                                              ,midd['child_prefix'])
                global_parm = self.__get_global_parm(midd_config['CONTENT'], code_)

                tcdict = temp_compare[0]
                tcdict.update(global_parm)
                # 计算匹配度，并放入list
                n = 0
                if len(temp_compare) > 1 and isinstance(temp_compare[1], list):
                    for tc in temp_compare[1]:
                        if tc == '':
                            continue
                        if tcdict[tc] != '' or tcdict[tc]:
                            n = n + 1
                    #compare.append(n)
                #result.append(tcdict)
                co = n
                rs.update(tcdict)

            rs.update(gr)

            #处理页面内容是PDF等附件类
            if midd_config['FILE']:
                FILE = midd_config['FILE']
                rs.update(self.__get_file(FILE,url,code_))


            if midd['child']:
                if not child_url:
                    raise Exception('child_url为空')
                for child,c_url in list(zip(midd['child'],child_url)):
                    child_rs, child_co = self.__request_middware(child,c_url)
                    rs.update(child_rs)
                    co = child_co + co

            return rs,co