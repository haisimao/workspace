# encoding: utf-8
from Env.Persistence import DBMPersistence
import random
import requests
import time
import dbm.dumb


class IPProxy(object):
    def __init__(self):
        """
        url:ip代理接口
        try_url:测试网址
        """
        self.url = 'http://183.131.114.29:9003/api/ip/get'
        self.try_url = 'https://www.baidu.com/'

    def get_ip(self):
        """
        获取和测试ip
        :return:
        """
        try:
            res = requests.get(url=self.url).json()
        except:
            raise Exception('网络异常!')
        if res.get('status') == 400:
            time.sleep(30)
            count = 0
            while True:
                if count < 11:
                    time.sleep(2)
                    try:
                        res = requests.get(url=self.url).json()
                    except:
                        raise Exception('网络异常!')
                    # print(res)
                    if res.get('status') == 200:
                        break
                    else:
                        count += 1
                        continue
                else:
                    return False
        ip = eval(res.get('result')).get('proxy')
        user_pass = eval(res.get('result')).get('user_pass')
        if ip:
            return '%s@%s' % (user_pass, ip)
        else:
            raise Exception('没有获取到ip!')

    def test_ip(self, ip):
        proxy = {'http': 'http://' + ip,
                 'https':'https://' + ip}
        try:
            res = requests.get(url=self.try_url, headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1'},proxies=proxy)
        except:
            return None
        if res.status_code == 200:
            return ip
        else:
            return None

    def ip_persistence(self):
        use_ip = self.get_ip()
        ip = self.test_ip(use_ip)
        if ip is None:
            ip = self.ip_persistence()
        return ip


class IPWeChat(object):
    def __init__(self):
        """
        url:ip代理接口
        try_url:测试网址
        """
        self.url = 'http://183.131.114.29:9003/api/ip/get'
        self.try_url = 'https://www.baidu.com/'
        self.ips = dict()

    def get_ip(self):
        """
        获取和测试ip
        :return:
        """
        try:
            res = requests.get(url=self.url).json()
        except:
            raise Exception('网络异常!')
        if res.get('status') == 400:
            time.sleep(30)
            count = 0
            while True:
                if count < 11:
                    time.sleep(2)
                    try:
                        res = requests.get(url=self.url).json()
                    except:
                        raise Exception('网络异常!')
                    # print(res)
                    if res.get('status') == 200:
                        break
                    else:
                        count += 1
                        continue
                else:
                    return False
        ip = eval(res.get('result')).get('proxy')
        user_pass = eval(res.get('result')).get('user_pass')
        if ip:
            return 'http://%s@%s' % (user_pass, ip)

        else:
            raise Exception('没有获取到ip!')

    def test_ip(self, ip):
        proxy = {'http': ip}
        res = requests.get(url=self.try_url, proxies=proxy)
        if res.status_code == 200:
            return ip
        else:
            return None

    def delete(self, ip):
        del self.ips[ip]

    def clear(self, ips):
        ips.clear()

    def ip_pre(self):
        ip = self.get_ip()
        count = 0
        while True:
            if ip in list(self.ips.keys()):
                ip = self.get_ip()
                # print('same:' + ip)
                continue
            else:
                test_ip = self.test_ip(ip)
                if test_ip is not None:
                    self.ips[ip] = int(time.time())
                    # print(self.ips)
                else:
                    self.delete([test_ip])
                    ip = self.get_ip()
                    self.ips[ip] = int(time.time())
                count += 1
                if count > 8:
                    break
        # print(self.ips)
        for k, v in self.ips.items():
            DBMPersistence().save(k,v)

    def g_ip(self):
        ip = DBMPersistence().load_ip()
        if ip is not None:
            ip = self.test_ip(ip)
            if ip is not None:
                return ip
            else:
                DBMPersistence().del_key(key=ip)
                self.g_ip()
        else:
            self.ip_pre()
            ip = DBMPersistence().load_ip()
            return ip


if __name__ == '__main__':
    print(IPProxy().ip_persistence())