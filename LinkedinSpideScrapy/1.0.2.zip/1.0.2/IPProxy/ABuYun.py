import time

import requests


# 要访问的目标页面
from Env.Persistence import DBMPersistence


class ABU(object):
    def test_ip(self, ip):
        proxy = {'http': ip,
                 'https':ip}
        try:
            res = requests.get(url='http://weixin.sogou.com/weixin', proxies=proxy)
        except:
            return None
        if res.status_code == 200:
            return ip
        else:
            return None

    def a_bu_yun(self):

        # 代理服务器
        proxyHost = "http-dyn.abuyun.com"
        proxyPort = "9020"

        # 代理隧道验证信息
        proxyUser = "H0NI472260ZV84ZD"
        proxyPass = "8AA76728846BC160"
        time.sleep(1)
        proxyMeta = "http://%(user)s:%(pass)s@%(host)s:%(port)s" % {
          "host": proxyHost,
          "port": proxyPort,
          "user": proxyUser,
          "pass": proxyPass,
        }
        ip = self.test_ip(proxyMeta)

        if ip is not None:
            return ip
        else:
            return None

    def request_ip(self):
        ip_dict = {}
        num = 8
        try:
            while num:
                ip = self.a_bu_yun()
                if ip:
                    ip_dict[ip] = time.time()
                    num -= 1
                else:
                    continue
            for k, v in ip_dict.items():
                DBMPersistence().save(k, v)
            return True
        except:
            return False

    def abu_get_ip(self):
        ip = DBMPersistence().load_ip()
        if ip:
            ip = self.test_ip(ip)
            if ip is not None:
                return ip
            else:
                DBMPersistence().clear_keys()
                self.request_ip()
                ip = DBMPersistence().load_ip()
                return ip
        else:
            self.request_ip()
            ip = DBMPersistence().load_ip()
            return ip




if __name__ == '__main__':
    print(ABU().a_bu_yun())