

import requests
import time

from Env.Persistence import DBMPersistence


class FastProxy(object):
    def test_ip(self, ip):
        proxy = {'http': ip,
                 'https':ip}
        try:
            res = requests.get(url='http://weixin.sogou.com/weixin', proxies=proxy)
        except:
            return None
        if res.status_code == 200:
            return ip
        else:
            return None

    def request_ip(self):
        ip_dict = {}
        re = requests.get(url='http://dps.kdlapi.com/api/getdps/?orderid=984226294970714&num=10&pt=1&format=json&sep=1').json()
        ips = list(re.get('data').get('proxy_list'))
        for i in ips:
            ip_dict['http://' + i] = int(time.time())
        for k, v in ip_dict.items():
            DBMPersistence().save(k, v)

    def get_ip(self):
        ip = DBMPersistence().load_ip()
        if ip:
            ip = self.test_ip(ip)
            if ip is not None:
                return ip
            else:
                DBMPersistence().clear_keys()
                self.request_ip()
                ip = DBMPersistence().load_ip()
                return ip
        else:
            self.request_ip()
            ip = DBMPersistence().load_ip()
            return ip


if __name__ == '__main__':
    print(FastProxy().get_ip())
