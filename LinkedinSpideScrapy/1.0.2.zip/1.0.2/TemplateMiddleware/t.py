import sys

def text11():
    return 'aa'

if __name__ == '__main__':
    sys.stdout.write(text11())
