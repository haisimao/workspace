import os

# 当前版本
VERSION_NUMBER = '1.0.2'
# VERSION_NUMBER = os.path.dirname(__file__).split('/')[-1]

